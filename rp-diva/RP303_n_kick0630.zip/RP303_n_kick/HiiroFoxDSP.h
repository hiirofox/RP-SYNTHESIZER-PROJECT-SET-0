#ifndef _FOX_DSP_
#define _FOX_DSP_

#ifdef __cplusplus  //c++ for Arduino(ESP32)

/*
ctof = ctof > 1.0 ? 1.0 : ctof;
    reso = reso > 1.0 ? 1.0 : reso;
    ctof = ctof < 0.0 ? 0.0 : ctof;
    reso = reso < 0.0 ? 0.0 : reso;
*/
class Filter {
private:
  float tmp1 = 0, tmp2 = 0, out1 = 0, out2 = 0;
public:
  void reset() {
    tmp1 = 0, tmp2 = 0, out1 = 0, out2 = 0;
  }
  float LPF1(float vin, float ctof, float reso) {
    float fb = reso + reso / (1.0 - ctof);
    tmp1 += ctof * (vin - tmp1 + fb * (tmp1 - out1));
    out1 += ctof * (tmp1 - out1);
    return out1;
  }
  float LPF2(float vin, float ctof, float reso) {
    float fb = reso + reso / (1.0 - ctof);
    tmp1 += ctof * (vin - tmp1 + fb * (tmp1 - out1));
    out1 += ctof * (tmp1 - out1);
    tmp2 += ctof * (out1 - tmp2 + fb * (tmp2 - out2));
    out2 += ctof * (tmp2 - out2);
    return out2;
  }
  float HPF1(float vin, float ctof) {
    tmp1 += ctof * (vin - tmp1);
    return vin - tmp1;
  }
};

class VCO {  //绝顶的vco，rp厂所有
private:
  int32_t t1 = 0;
public:
  void debug() {
    Serial.println(t1);
  }
  void AutoZero() {
    if (t1 >= (int32_t)2147283647) t1 = 0;
  }
  float Saw(int SawFreq, int UniN, float delta) {
    //t1 += (SawFreq << 15) / SAMPLE_RATE;
    t1 += SawFreq;
    float tmp1 = 1;
    int tmp2 = 0;
    for (int i = 0; i < UniN; ++i)
      //tmp2 += (uint16_t)((tmp1 *= delta) * t1);
      tmp2 += (uint32_t)((tmp1 *= delta) * (int32_t)t1) % SAMPLE_RATE;
    return tmp2 / UniN - (SAMPLE_RATE >> 1);
  }
  float Sqr(int SawFreq, int UniN, float delta, int PWM) {
    //t1 += (SawFreq << 15) / SAMPLE_RATE;
    t1 += SawFreq;
    float tmp1 = 1;
    int tmp2 = 0;
    for (int i = 0; i < UniN; ++i)
      //tmp2 += (uint16_t)((tmp1 *= delta) * t1);
      tmp2 += ((int)((tmp1 *= delta) * (int32_t)t1) % SAMPLE_RATE) > PWM ? -1 : 1;
    return tmp2 * (SAMPLE_RATE >> 1) / UniN;
  }
};

float sinmap[256];  //sin打表
bool IsSinMapInit = 0;
class HF_Sine {
private:
  float x = 1, y = 0;
public:
  HF_Sine() {
    if (!IsSinMapInit) {
      IsSinMapInit = true;
      for (int i = 0; i < 256; ++i)
        sinmap[i] = sin((double)i / 255.0 * 2.0 * M_PI);
    }
  }
  float sin256(double t256) {  //t:(0.0~255.0)->(0~2.0*M_PI rad)
    return sinmap[(uint8_t)t256] - (t256 - (int)t256) * (sinmap[(uint8_t)(t256 + 1.0)] - sinmap[(uint8_t)t256]);
  }
  float sin256_fast(double t256) {
    return sinmap[(uint8_t)t256];
  }
  float sin_addt(float freq) {  //sin(t+=freq)  freq:(0.0~1.0)->(0~SAMPLE_RATE hz)
    y += x * freq;
    x -= y * freq;
    return y;
  }
  float cos_addt(float freq) {  //cos(t+=freq)
    y += x * freq;
    x -= y * freq;
    return x;
  }
  void Unitization() {
    float r = sqrt(x * x + y * y);
    x /= r;
    y /= r;
  }
  void ResetPhase() {
    x = 1, y = 0;
  }
  float dampsine(float freq, float damp) {
    y += x * freq;
    x -= y * freq;
    x *= damp;
    y *= damp;
    return y;
  }
};

class RP808DRUM {
private:
  float KickFreq = 0;  //kick
  //Filter osc;
  HF_Sine osc;
public:
  float kick(int trig) {
    KickFreq += 0.00015 * (10.0 - KickFreq);
    if (trig) {
      KickFreq = 29;
      //osc.reset();
      osc.ResetPhase();
    }
    //return osc.LPF2(trig * 32768, (KickFreq * KickFreq) / SAMPLE_RATE, 0.975);
    return osc.dampsine((KickFreq * KickFreq) / SAMPLE_RATE, 0.9999975) * 4096.0;
  }
};

#define Phaser_MaxApfN (32)
class phaser {
private:
  float apf_v0[Phaser_MaxApfN];
  float apf(float vin, float freq, int n) {
    apf_v0[n] += freq * (vin - apf_v0[n]);
    return apf_v0[n] * 2.0 - vin;
  }
  float v_fdbk;
public:
  void reset() {
    for (int i = 0; i < Phaser_MaxApfN; ++i)
      apf_v0[i] = 0;
  }
  phaser() {
    reset();
  }
  float proc(float in, float freq, float reso, float stat) {
    float v = in + reso * v_fdbk;
    for (int i = 0; i < (int)stat - 1; ++i)
      v = apf(v, freq, i);
    float v2 = apf(v, freq, (int)stat - 1);
    float mix = stat - (int)stat;
    return v_fdbk = v * (1.0 - mix) + v2 * (mix);
  }
  float proc_fast(float in, float freq, float reso, int stat) {
    float v = in + reso * v_fdbk;
    for (int i = 0; i < (int)stat; ++i)
      v = apf(v, freq, i);
    return v_fdbk = v;
  }
};


#else  //c for cdk(W806)

#endif

#endif  //hiirofox(gy314) dsp